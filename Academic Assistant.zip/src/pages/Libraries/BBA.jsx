import React from 'react'

const BBA = () => {
  return (
    <div>BBA</div>
  )
}

export default BBA
import React from 'react'

const CSE = () => {
  return (
    <div>CSE</div>
  )
}

export default CSE
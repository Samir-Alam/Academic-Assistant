import React from 'react'

const EE = () => {
  return (
    <div>EE</div>
  )
}

export default EE
import React from 'react'

const BCA = () => {
  return (
    <div>BCA</div>
  )
}

export default BCA
import React from 'react'

const ECE = () => {
  return (
    <div>ECE</div>
  )
}

export default ECE
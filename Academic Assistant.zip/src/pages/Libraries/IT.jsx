import React from 'react'

const IT = () => {
  return (
    <div>IT</div>
  )
}

export default IT
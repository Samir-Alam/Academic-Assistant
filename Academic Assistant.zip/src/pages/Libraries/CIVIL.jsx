import React from 'react'

const CIVIL = () => {
  return (
    <div>CIVIL</div>
  )
}

export default CIVIL
import React from 'react'
import Navbar from '../../components/Navbar'

const SciencePage = () => {
  return (
    <div>
        <Navbar />
    </div>
  )
}

export default SciencePage
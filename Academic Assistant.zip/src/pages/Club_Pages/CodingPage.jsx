import React from 'react'
import Navbar from '../../components/Navbar'

const CodingPage = () => {
  return (
    <div>
        <Navbar />
    </div>
  )
}

export default CodingPage
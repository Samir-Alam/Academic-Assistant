import React from 'react'
import Navbar from '../../components/Navbar'

const HardwarePage = () => {
  return (
    <div>
        <Navbar />
    </div>
  )
}

export default HardwarePage
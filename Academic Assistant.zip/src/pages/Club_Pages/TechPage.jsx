import React from 'react'
import Navbar from '../../components/Navbar'

const TechPage = () => {
  return (
    <div>
        <Navbar />
    </div>
  )
}

export default TechPage